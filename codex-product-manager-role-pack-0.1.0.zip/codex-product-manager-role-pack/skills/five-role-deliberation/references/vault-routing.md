# Vault routing

## Configured operating Vault

Read `~/.codex/codex-product-manager-role-pack.json` and use its `vault_path` for:

- the user's stable work habits and product-manager preferences;
- five-role project decisions, evaluation cases, usage feedback, and future growth proposals;
- global control, lessons, and project records.

Read only the root control files and the smallest relevant project subset. Never scan the whole Vault by default.

## Optional external research Vault

Only use a separate industry or company research Vault when its path is explicitly configured or the user provides it. Use it for:

- industry research, durable domain knowledge, AI Native and market/project research;
- sources and research records governed by its own nearest `AGENTS.md`.

Do not migrate or duplicate its content into the operating Vault. If both are relevant, use the operating Vault for preferences and project state, and the external Vault for research evidence.

## Growth hook, currently disabled

Record observed role misses, useful challenges, routing errors, and resource waste in the current project record or `06-Growth/个人目录/岗位/姓名/角色成长候选.md`. Do not automatically rewrite public role prompts on a schedule. Future growth must use proposed changes, replay tests, Human approval, and rollbackable versions.

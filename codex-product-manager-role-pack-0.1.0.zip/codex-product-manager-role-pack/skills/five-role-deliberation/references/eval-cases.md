# Routing evaluation cases

## Case A: complex product decision

Input: `是否应该在模型选择器中增加自动推荐功能？`

Expected:
- Route `DELIBERATE`.
- Researcher checks current model capabilities and evidence.
- Product Strategist examines value, user control, and interaction states.
- System Strategist examines recommendation logic, explainability, fallback, and cost.
- Red Team challenges automation bias and false confidence.
- Final output is a decision report, not implementation.

## Case B: clear interaction edit

Input: `把已确认弹窗里的“确定”改成“保存”，其他不动。直接执行。`

Expected:
- Route `BYPASS`.
- Do not run five specialists.
- Use the relevant design or coding skill and verify the small change.

## Case C: stalled Agent architecture debate

Input: `这个 Agent 架构已经讨论多轮仍没有结论，继续五角色审议。`

Expected:
- Route `DELIBERATE`.
- Do not repeat prior wording.
- After bounded ordinary rounds stall, xhigh first returns `STOP`, `REDIRECT`, or `CONTINUE` with expected gain and stop condition.
- `REDIRECT` or `CONTINUE` allows one or two bounded rounds.
- If still stalled, xhigh may re-enter the value gate; it is not limited to one use.
